import os, tempfile
os.environ["MEDIMIND_DB"] = tempfile.mktemp(suffix=".db")
from fastapi.testclient import TestClient
from app.main import app

c = TestClient(app)
def H(t): return {"Authorization": f"Bearer {t}"}

def test_full_flow():
    assert c.get("/api/state").status_code == 401
    assert c.post("/api/auth/login", json={"email": "a@x.com", "password": "password1"}).status_code == 404
    assert c.post("/api/auth/register", json={"email": "a@x.com", "password": "short"}).status_code == 422
    t = c.post("/api/auth/register", json={"email": "A@x.com", "password": "password1"}).json()["token"]
    assert c.post("/api/auth/register", json={"email": "a@x.com", "password": "password1"}).status_code == 409
    assert c.post("/api/auth/login", json={"email": "a@x.com", "password": "wrongpass1"}).status_code == 401
    h = H(t)

    s = c.get("/api/state", headers=h).json()
    assert s["records"] == [] and s["tests"] == {}
    assert c.get("/api/insights", headers=h).json()["ready"] is False

    assert c.put("/api/profile", headers=h, json={"name": "Sam", "age": 30, "height": 170, "weight": 70}).status_code == 200
    r = c.post("/api/health-entry", headers=h, json={"hr": 72, "bp": "150/95", "temp": 101, "weight": 72.5, "symptom": "Headache", "severity": "Mild"})
    assert r.status_code == 201
    assert c.post("/api/health-entry", headers=h, json={}).status_code == 422
    assert c.post("/api/vitals", headers=h, json={"bp": "abc"}).status_code == 422
    assert c.post("/api/vitals", headers=h, json={"hr": 5000}).status_code == 422
    assert c.post("/api/vitals", headers=h, json={"hr": 110}).status_code == 201
    assert c.post("/api/symptoms", headers=h, json={"name": "Cough", "severity": "Bad"}).status_code == 422
    assert c.post("/api/records", headers=h, json={"title": "Checkup", "notes": "ok"}).status_code == 201
    assert c.post("/api/medications", headers=h, json={"name": "Vit D", "dose": "1000IU", "schedule": "Morning"}).status_code == 201
    assert c.post("/api/appointments", headers=h, json={"name": "Dentist", "date": "2026-11-02", "time": "10:30"}).status_code == 201
    assert c.post("/api/appointments", headers=h, json={"name": "x", "date": "nope"}).status_code == 422

    assert c.post("/api/tests/heart", headers=h, json={"answers": [3, 0, 2, 0, 0]}).json()["percent"] == 38
    assert c.post("/api/tests/heart", headers=h, json={"answers": [1, 1, 1, 1, 1]}).status_code == 422
    assert c.post("/api/tests/sleep", headers=h, json={"answers": [2, 2, 2, 2]}).json()["score"] == 8
    assert c.post("/api/tests/nope", headers=h, json={"answers": []}).status_code == 404

    s = c.get("/api/state", headers=h).json()
    assert s["vitals"]["hr"] == 110 and s["vitals"]["bp"] == "150/95" and s["vitals"]["weight"] == 72.5
    assert s["profile"]["weight"] == 72.5
    assert len(s["records"]) == 3 and len(s["symptoms"]) == 1 and s["tests"]["heart"]["score"] == 5
    i = c.get("/api/insights", headers=h).json()
    txt = " ".join(i["tips"])
    assert i["ready"] and "above 100 BPM" in txt and "blood pressure is high" in txt and "temperature is elevated" in txt
    assert i["bmi"] == 25.1

    # isolation between users
    t2 = c.post("/api/auth/register", json={"email": "b@x.com", "password": "password2"}).json()["token"]
    assert c.get("/api/state", headers=H(t2)).json()["medications"] == []
    mid = s["medications"][0]["id"]
    assert c.delete(f"/api/medications/{mid}", headers=H(t2)).status_code == 404
    assert c.delete(f"/api/medications/{mid}", headers=h).status_code == 204
    assert c.delete("/api/users/1", headers=h).status_code == 404
    assert c.delete("/api/account", headers=h).status_code == 204
    assert c.get("/api/state", headers=h).status_code == 401

def test_static():
    assert c.get("/").status_code == 200 and b"MediMind" in c.get("/").content
    assert c.get("/static/api.js").status_code == 200
