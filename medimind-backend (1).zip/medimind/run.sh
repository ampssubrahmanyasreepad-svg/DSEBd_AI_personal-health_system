#!/usr/bin/env bash
pip install -r requirements.txt -q
uvicorn app.main:app --host 0.0.0.0 --port ${PORT:-8000} --reload
