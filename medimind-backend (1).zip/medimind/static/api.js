/* MediMind — backend wiring. Loaded after the inline script; overrides its localStorage functions. */
const TOKEN_KEY = 'medimind_token';
let insights = null;
const $ = id => document.getElementById(id);
const val = id => $(id).value;

async function api(path, opts = {}) {
  const token = localStorage.getItem(TOKEN_KEY);
  const res = await fetch('/api' + path, {
    method: opts.method || 'GET',
    headers: { 'Content-Type': 'application/json', ...(token ? { Authorization: 'Bearer ' + token } : {}) },
    body: opts.body ? JSON.stringify(opts.body) : undefined,
  });
  if (res.status === 401 && token && !path.startsWith('/auth')) { logout(); throw new Error('Session expired — please sign in again'); }
  if (res.status === 204) return null;
  const json = await res.json().catch(() => ({}));
  if (!res.ok) {
    let msg = json.detail;
    if (Array.isArray(msg)) msg = msg.map(e => (e.msg || '').replace('Value error, ', '')).join('; ');
    const err = new Error(msg || 'Request failed'); err.status = res.status; throw err;
  }
  return json;
}
const num = v => (v === '' || v == null ? null : Number(v));
const guard = fn => async (...a) => { try { await fn(...a); } catch (e) { toast(e.message); } };

async function refresh() {
  const [s, i] = await Promise.all([api('/state'), api('/insights')]);
  Object.assign(data, s); insights = i;
  render(); restoreTests(); updateAI();
}

function showApp() { $('login').style.display = 'none'; $('app').style.display = 'block'; }

// ---- overrides of the original localStorage-based functions ----
save = () => {};

login = guard(async function () {
  const email = val('email').trim(), password = val('password');
  if (!email || !password) return toast('Enter your email and password');
  let r;
  try { r = await api('/auth/login', { method: 'POST', body: { email, password } }); }
  catch (e) {
    if (e.status !== 404) throw e;
    r = await api('/auth/register', { method: 'POST', body: { email, password } });
  }
  localStorage.setItem(TOKEN_KEY, r.token);
  showApp(); await refresh();
  if (!data.profile.name) openModal('profileModal');
  toast('Signed in ✓');
});

logout = function () {
  localStorage.removeItem(TOKEN_KEY);
  $('app').style.display = 'none'; $('login').style.display = 'grid';
  $('email').value = ''; $('password').value = '';
};

saveProfile = guard(async function () {
  const name = val('pName').trim();
  if (!name) return toast('Please enter your name');
  await api('/profile', { method: 'PUT', body: { name, age: num(val('pAge')), height: num(val('pHeight')), weight: num(val('pWeight')) } });
  closeModal('profileModal'); await refresh(); toast('Profile saved ✓');
});

saveHealthData = guard(async function () {
  await api('/health-entry', { method: 'POST', body: {
    weight: num(val('inWeight')), hr: num(val('inHR')), bp: val('inBP') || null, temp: num(val('inTemp')),
    symptom: val('inSymptom').trim(), severity: val('inSeverity') } });
  await refresh(); toast('Your health data was saved ✓');
});

saveVitals = guard(async function () {
  await api('/vitals', { method: 'POST', body: { hr: num(val('mHR')), bp: val('mBP') || null, temp: num(val('mTemp')), weight: num(val('mWeight')) } });
  closeModal('vitalModal'); await refresh(); toast('Vitals saved ✓');
});

saveSymptom = guard(async function () {
  const name = val('sName').trim();
  if (!name) return toast('Enter a symptom');
  await api('/symptoms', { method: 'POST', body: { name, severity: val('sSeverity') } });
  closeModal('symptomModal'); await refresh(); toast('Symptom saved ✓');
});

addRecord = guard(async function () {
  const title = val('rTitle').trim();
  if (!title) return toast('Enter a record title');
  await api('/records', { method: 'POST', body: { title, notes: val('rNotes') || null } });
  closeModal('recordModal'); await refresh(); toast('Record saved ✓');
});

addMedication = guard(async function () {
  const name = val('medName').trim();
  if (!name) return toast('Enter medication name');
  await api('/medications', { method: 'POST', body: { name, dose: val('medDose'), schedule: val('medSchedule') } });
  closeModal('medModal'); await refresh(); toast('Medication added ✓');
});

addAppointment = guard(async function () {
  const name = val('aName').trim();
  if (!name) return toast('Enter appointment name');
  await api('/appointments', { method: 'POST', body: { name, date: val('aDate') || null, time: val('aTime') || null } });
  closeModal('apptModal'); await refresh(); toast('Appointment added ✓');
});

const runTest = (name, ids, label) => guard(async function () {
  await api('/tests/' + name, { method: 'POST', body: { answers: ids.map(id => Number(val(id))) } });
  await refresh(); toast(label + ' test completed ✓');
});
runHeartTest = runTest('heart', ['heartQ1', 'heartQ2', 'heartQ3', 'heartQ4', 'heartQ5'], 'Heart wellness');
runSleepTest = runTest('sleep', ['sleep1', 'sleep2', 'sleep3', 'sleep4'], 'Sleep');
runLifeTest = runTest('life', ['life1', 'life2', 'life3', 'life4'], 'Lifestyle');

// AI text now comes from the server's insight engine
aiText = () => (insights ? insights.dashboard_summary : 'Enter health information to generate your personalized summary.');

updateAI = function () {
  if (!insights) return;
  const i = insights;
  $('aiStatus').textContent = i.status; $('aiTitle').textContent = i.title; $('aiText').textContent = i.summary;
  $('aiTags').innerHTML = i.tags.map(x => `<span class="tag">${x}</span>`).join('');
  const tl = $('tipList');
  if (i.tips.length) {
    tl.className = 'list';
    tl.innerHTML = i.tips.map(x => `<div class="item"><div class="ileft"><div class="id"></div><div><b>Personalized tip</b><small>${x}</small></div></div></div>`).join('');
  } else { tl.className = 'empty'; tl.textContent = i.ready ? 'Add more information for better tips.' : 'No personalized tips yet.'; }
  const as = $('aiAssessment');
  if (i.assessment.length) { as.className = ''; as.innerHTML = i.assessment.map(x => `<div class="item" style="margin-bottom:10px"><b>${x}</b><span class="status">Calculated</span></div>`).join(''); }
  else { as.className = 'empty'; as.textContent = 'Complete a test to see your assessment here.'; }
  const bt = $('bmiTest');
  if (i.bmi) { bt.className = 'item'; bt.innerHTML = `<div><b>BMI</b><small>Calculated from your profile height and weight</small></div><b>${i.bmi}</b>`; }
};

// restore session on page load
window.addEventListener('load', guard(async () => {
  if (!localStorage.getItem(TOKEN_KEY)) return;
  try { await api('/profile'); showApp(); await refresh(); }
  catch { logout(); }
}));
