"""Wellness insight engine (server-side port of the frontend's updateAI logic)."""
import re

# (question key, allowed answer values) -> used to validate and score tests
TESTS = {
    "heart": [{0, 1, 2, 3}, {0, 2, 3}, {0, 1, 2}, {0, 2, 3}, {0, 1, 2}],
    "sleep": [{0, 1, 2, 3}, {0, 1, 2}, {0, 1, 2}, {0, 1, 2}],
    "life":  [{0, 1, 2}, {0, 1, 2}, {0, 1, 2}, {0, 1, 2}],
}
TEST_MAX = {"heart": 13, "sleep": 9, "life": 8}
TEST_LABEL = {"heart": "Heart", "sleep": "Sleep", "life": "Lifestyle"}


def score_class(score, mx):
    pct = score / mx * 100
    return "Good" if pct >= 75 else "Fair" if pct >= 50 else "Needs attention"


def bmi(weight, height_cm):
    try:
        w, h = float(weight), float(height_cm)
    except (TypeError, ValueError):
        return None
    if not w or not h:
        return None
    return w / ((h / 100) ** 2)


def dashboard_summary(vitals, symptoms, b):
    parts = []
    if vitals.get("hr"):
        parts.append(f"You entered a heart rate of {vitals['hr']} BPM.")
    if vitals.get("bp"):
        parts.append(f"Your recorded blood pressure is {vitals['bp']}.")
    if vitals.get("temp"):
        parts.append(f"Your recorded temperature is {vitals['temp']} °F.")
    if b:
        parts.append(f"Your calculated BMI is {b:.1f}.")
    if symptoms:
        parts.append(f"You reported {symptoms[0]['name']} with {symptoms[0]['severity'].lower()} severity.")
    if not parts:
        return "Enter health information to generate your personalized summary."
    return ("The system reviewed the information you provided. " + " ".join(parts) +
            " Continue tracking your information over time and discuss concerning changes "
            "with a qualified healthcare professional.")


def build_insights(profile, vitals, symptoms, tests, record_count):
    tips, tags, assessment = [], [], []
    b = bmi(profile.get("weight"), profile.get("height"))

    if b:
        if b < 18.5:
            tips.append("Your BMI is below the usual adult reference range. Consider discussing nutrition and healthy weight goals with a professional.")
        elif b >= 25:
            tips.append("Your BMI is above the usual adult reference range. Focus on sustainable activity and balanced nutrition rather than rapid changes.")
        else:
            tips.append("Your BMI falls within the usual adult reference range. Continue your current healthy habits.")
        tags.append("BMI calculated")
        assessment.append(f"BMI: {b:.1f}")

    if vitals.get("hr"):
        n = float(vitals["hr"])
        if n > 100:
            tips.append("Your entered resting heart rate is above 100 BPM. Consider rechecking when relaxed and seek professional advice if it remains unusually high or you feel unwell.")
        elif n < 60:
            tips.append("Your entered heart rate is below 60 BPM. This can be normal for some people, but discuss it with a professional if you have symptoms.")
        else:
            tips.append("Your entered heart rate is within a commonly used adult resting range. Keep tracking it consistently.")
        tags.append("Heart rate entered")

    if vitals.get("temp") and float(vitals["temp"]) >= 100.4:
        tips.append("Your entered temperature is elevated. Rest, stay hydrated, and consider professional medical advice if symptoms are significant or persistent.")

    if vitals.get("bp"):
        m = re.match(r"\s*(\d{2,3})\s*[/|]\s*(\d{2,3})", vitals["bp"])
        if m:
            sys_, dia = int(m.group(1)), int(m.group(2))
            if sys_ >= 140 or dia >= 90:
                tips.append("Your entered blood pressure is high. Recheck using a proper monitor and discuss repeated high readings with a healthcare professional.")
            elif sys_ >= 130 or dia >= 80:
                tips.append("Your blood pressure reading is above the ideal range. Keep tracking readings and discuss repeated elevations with a professional.")
            else:
                tips.append("Your entered blood pressure is below common high-blood-pressure thresholds. Continue regular monitoring.")
            tags.append("Blood pressure entered")

    if symptoms:
        s = symptoms[0]
        tips.append(f"You reported {s['name']} ({s['severity']}). Keep a record of when it occurs and how it changes.")
        tags.append("Symptoms included")

    msgs = {
        "heart": ("Your heart wellness questionnaire suggests there are lifestyle areas worth improving, especially regular activity and tobacco avoidance.",
                  "Your heart wellness questionnaire suggests a generally positive lifestyle pattern. Keep building consistent habits."),
        "sleep": ("Your sleep questionnaire suggests improving sleep consistency and aiming for enough quality sleep may be useful.",
                  "Your sleep questionnaire suggests a fairly healthy sleep pattern. Keep your schedule consistent."),
        "life":  ("Your lifestyle questionnaire highlights opportunities around hydration, nutrition, activity, or stress management.",
                  "Your lifestyle questionnaire suggests several healthy daily habits are already in place."),
    }
    for key in ("heart", "sleep", "life"):
        t = tests.get(key)
        if t:
            pct = t["score"] / t["max"] * 100
            tags.append(f"{TEST_LABEL[key]} test completed")
            tips.append(msgs[key][0] if pct < 50 else msgs[key][1])
            assessment.append(f"{TEST_LABEL[key]}: {round(pct)}%")

    has_data = bool(any(vitals.values()) or symptoms or record_count or tests)
    return {
        "ready": has_data,
        "status": "● Analysis ready" if has_data else "● Waiting for data",
        "title": "Here are your personalized wellness tips" if has_data else "Your AI health coach is waiting",
        "summary": ("MediMind reviewed the information you entered and the assessments you completed. "
                    "These suggestions are general wellness guidance, not a diagnosis.") if has_data else
                   "Enter your health information and complete the available tests. MediMind will turn your inputs into personalized wellness tips.",
        "dashboard_summary": dashboard_summary(vitals, symptoms, b),
        "tags": tags,
        "tips": tips,
        "assessment": assessment,
        "bmi": round(b, 1) if b else None,
        "disclaimer": "General wellness suggestions only. Not a medical diagnosis.",
    }
