"""MediMind backend — FastAPI + SQLite."""
import hashlib, hmac, json, os, re, secrets, sqlite3
from datetime import date, datetime, timedelta, timezone
from pathlib import Path
from typing import List, Optional

import jwt
from fastapi import Depends, FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import FileResponse
from fastapi.security import HTTPAuthorizationCredentials, HTTPBearer
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel, Field, field_validator

from .insights import TESTS, TEST_MAX, build_insights

BASE = Path(__file__).resolve().parent.parent
DB_PATH = os.getenv("MEDIMIND_DB", str(BASE / "medimind.db"))
SECRET = os.getenv("MEDIMIND_SECRET") or secrets.token_hex(32)  # set it in prod, or tokens reset on restart
TOKEN_HOURS = int(os.getenv("MEDIMIND_TOKEN_HOURS", "72"))
EMAIL_RE = re.compile(r"^[^@\s]+@[^@\s]+\.[^@\s]+$")
BP_RE = re.compile(r"^\s*\d{2,3}\s*[/|]\s*\d{2,3}\s*$")

SCHEMA = """
CREATE TABLE IF NOT EXISTS users(
  id INTEGER PRIMARY KEY AUTOINCREMENT, email TEXT UNIQUE NOT NULL,
  pw_hash TEXT NOT NULL, name TEXT, age INTEGER, height REAL, weight REAL,
  created_at TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS vitals(
  id INTEGER PRIMARY KEY AUTOINCREMENT, user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  hr REAL, bp TEXT, temp REAL, weight REAL, created_at TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS symptoms(
  id INTEGER PRIMARY KEY AUTOINCREMENT, user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  name TEXT NOT NULL, severity TEXT NOT NULL, created_at TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS records(
  id INTEGER PRIMARY KEY AUTOINCREMENT, user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  title TEXT NOT NULL, vitals_json TEXT NOT NULL DEFAULT '{}', notes TEXT, created_at TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS medications(
  id INTEGER PRIMARY KEY AUTOINCREMENT, user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  name TEXT NOT NULL, dose TEXT, schedule TEXT, created_at TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS appointments(
  id INTEGER PRIMARY KEY AUTOINCREMENT, user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  name TEXT NOT NULL, date TEXT, time TEXT, created_at TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS test_results(
  id INTEGER PRIMARY KEY AUTOINCREMENT, user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  test TEXT NOT NULL, score INTEGER NOT NULL, max INTEGER NOT NULL, answers_json TEXT NOT NULL, created_at TEXT NOT NULL);
CREATE INDEX IF NOT EXISTS ix_vitals_u ON vitals(user_id,id);
CREATE INDEX IF NOT EXISTS ix_sym_u ON symptoms(user_id,id);
CREATE INDEX IF NOT EXISTS ix_rec_u ON records(user_id,id);
CREATE INDEX IF NOT EXISTS ix_test_u ON test_results(user_id,test,id);
"""


def now():
    return datetime.now(timezone.utc).isoformat(timespec="seconds")


def connect():
    c = sqlite3.connect(DB_PATH, check_same_thread=False)
    c.row_factory = sqlite3.Row
    c.execute("PRAGMA foreign_keys=ON")
    c.execute("PRAGMA journal_mode=WAL")
    return c


def init_db():
    with connect() as c:
        c.executescript(SCHEMA)


def get_db():
    c = connect()
    try:
        yield c
        c.commit()
    finally:
        c.close()


# ---------- auth ----------
def hash_pw(pw: str) -> str:
    salt = secrets.token_bytes(16)
    h = hashlib.scrypt(pw.encode(), salt=salt, n=2**14, r=8, p=1)
    return salt.hex() + "$" + h.hex()


def check_pw(pw: str, stored: str) -> bool:
    salt, h = stored.split("$")
    cand = hashlib.scrypt(pw.encode(), salt=bytes.fromhex(salt), n=2**14, r=8, p=1)
    return hmac.compare_digest(cand.hex(), h)


def make_token(uid: int) -> str:
    exp = datetime.now(timezone.utc) + timedelta(hours=TOKEN_HOURS)
    return jwt.encode({"sub": str(uid), "exp": exp}, SECRET, algorithm="HS256")


bearer = HTTPBearer(auto_error=False)


def current_user(cred: Optional[HTTPAuthorizationCredentials] = Depends(bearer), db=Depends(get_db)):
    if not cred:
        raise HTTPException(401, "Not authenticated")
    try:
        uid = int(jwt.decode(cred.credentials, SECRET, algorithms=["HS256"])["sub"])
    except Exception:
        raise HTTPException(401, "Invalid or expired token")
    u = db.execute("SELECT * FROM users WHERE id=?", (uid,)).fetchone()
    if not u:
        raise HTTPException(401, "User no longer exists")
    return u


# ---------- schemas ----------
class Credentials(BaseModel):
    email: str
    password: str = Field(min_length=8, max_length=128)

    @field_validator("email")
    @classmethod
    def _email(cls, v):
        v = v.strip().lower()
        if not EMAIL_RE.match(v) or len(v) > 254:
            raise ValueError("Enter a valid email")
        return v


class ProfileIn(BaseModel):
    name: str = Field(min_length=1, max_length=100)
    age: Optional[int] = Field(None, ge=0, le=130)
    height: Optional[float] = Field(None, gt=0, le=300)
    weight: Optional[float] = Field(None, gt=0, le=700)


class VitalsIn(BaseModel):
    hr: Optional[float] = Field(None, gt=20, le=300)
    bp: Optional[str] = None
    temp: Optional[float] = Field(None, ge=80, le=115)  # °F
    weight: Optional[float] = Field(None, gt=0, le=700)

    @field_validator("bp")
    @classmethod
    def _bp(cls, v):
        if v in (None, ""):
            return None
        if not BP_RE.match(v):
            raise ValueError("Blood pressure must look like 120/80")
        return v.replace(" ", "").replace("|", "/")

    def has_any(self):
        return any(x is not None for x in (self.hr, self.bp, self.temp, self.weight))


class SymptomIn(BaseModel):
    name: str = Field(min_length=1, max_length=200)
    severity: str = "Mild"

    @field_validator("severity")
    @classmethod
    def _sev(cls, v):
        if v not in ("None", "Mild", "Moderate", "Severe"):
            raise ValueError("Severity must be None, Mild, Moderate or Severe")
        return v


class HealthEntryIn(VitalsIn):
    symptom: Optional[str] = Field(None, max_length=500)
    severity: str = "None"


class RecordIn(BaseModel):
    title: str = Field(min_length=1, max_length=200)
    notes: Optional[str] = Field(None, max_length=5000)


class MedIn(BaseModel):
    name: str = Field(min_length=1, max_length=200)
    dose: Optional[str] = Field(None, max_length=100)
    schedule: Optional[str] = Field(None, max_length=200)


class ApptIn(BaseModel):
    name: str = Field(min_length=1, max_length=200)
    date: Optional[str] = None
    time: Optional[str] = None

    @field_validator("date")
    @classmethod
    def _d(cls, v):
        if v:
            date.fromisoformat(v)
        return v or None

    @field_validator("time")
    @classmethod
    def _t(cls, v):
        if v and not re.match(r"^([01]\d|2[0-3]):[0-5]\d$", v):
            raise ValueError("Time must be HH:MM")
        return v or None


class TestIn(BaseModel):
    answers: List[int]


# ---------- helpers ----------
def latest_vitals(db, uid):
    out = {}
    for f in ("hr", "bp", "temp", "weight"):
        r = db.execute(f"SELECT {f} FROM vitals WHERE user_id=? AND {f} IS NOT NULL ORDER BY id DESC LIMIT 1", (uid,)).fetchone()
        out[f] = r[0] if r else None
    return out


def latest_tests(db, uid):
    out = {}
    for t in TESTS:
        r = db.execute("SELECT score,max,created_at FROM test_results WHERE user_id=? AND test=? ORDER BY id DESC LIMIT 1", (uid, t)).fetchone()
        if r:
            out[t] = {"score": r["score"], "max": r["max"], "date": r["created_at"]}
    return out


def profile_of(u):
    return {"name": u["name"], "age": u["age"], "height": u["height"], "weight": u["weight"]}


def d(ts):  # ISO timestamp -> date string
    return ts[:10]


def save_vitals_row(db, uid, v: VitalsIn, title: str, notes: Optional[str] = None):
    ts = now()
    db.execute("INSERT INTO vitals(user_id,hr,bp,temp,weight,created_at) VALUES(?,?,?,?,?,?)", (uid, v.hr, v.bp, v.temp, v.weight, ts))
    if v.weight is not None:
        db.execute("UPDATE users SET weight=? WHERE id=?", (v.weight, uid))
    vit = {k: val for k, val in v.model_dump(include={"hr", "bp", "temp", "weight"}).items() if val is not None}
    db.execute("INSERT INTO records(user_id,title,vitals_json,notes,created_at) VALUES(?,?,?,?,?)", (uid, title, json.dumps(vit), notes, ts))


def rows(db, sql, args):
    return [dict(r) for r in db.execute(sql, args).fetchall()]


# ---------- app ----------
app = FastAPI(title="MediMind API", version="1.0.0")
app.add_middleware(CORSMiddleware, allow_origins=os.getenv("MEDIMIND_CORS", "*").split(","),
                   allow_methods=["*"], allow_headers=["*"])
init_db()


@app.get("/api/health")
def health():
    return {"status": "ok"}


# --- auth ---
@app.post("/api/auth/register", status_code=201)
def register(c: Credentials, db=Depends(get_db)):
    if db.execute("SELECT 1 FROM users WHERE email=?", (c.email,)).fetchone():
        raise HTTPException(409, "An account with this email already exists")
    cur = db.execute("INSERT INTO users(email,pw_hash,created_at) VALUES(?,?,?)", (c.email, hash_pw(c.password), now()))
    return {"token": make_token(cur.lastrowid), "email": c.email}


@app.post("/api/auth/login")
def login(c: Credentials, db=Depends(get_db)):
    u = db.execute("SELECT * FROM users WHERE email=?", (c.email,)).fetchone()
    if not u:
        raise HTTPException(404, "No account found for this email")
    if not check_pw(c.password, u["pw_hash"]):
        raise HTTPException(401, "Incorrect password")
    return {"token": make_token(u["id"]), "email": u["email"]}


@app.delete("/api/account", status_code=204)
def delete_account(u=Depends(current_user), db=Depends(get_db)):
    db.execute("DELETE FROM users WHERE id=?", (u["id"],))


# --- profile ---
@app.get("/api/profile")
def get_profile(u=Depends(current_user)):
    return {"email": u["email"], **profile_of(u)}


@app.put("/api/profile")
def put_profile(p: ProfileIn, u=Depends(current_user), db=Depends(get_db)):
    db.execute("UPDATE users SET name=?,age=?,height=?,weight=? WHERE id=?", (p.name.strip(), p.age, p.height, p.weight, u["id"]))
    return {"email": u["email"], **p.model_dump()}


# --- one-shot state for the dashboard (same shape the frontend already uses) ---
@app.get("/api/state")
def state(u=Depends(current_user), db=Depends(get_db)):
    uid = u["id"]
    recs = rows(db, "SELECT * FROM records WHERE user_id=? ORDER BY id DESC LIMIT 200", (uid,))
    return {
        "email": u["email"],
        "profile": {k: ("" if v is None else v) for k, v in profile_of(u).items()},
        "vitals": {k: ("" if v is None else v) for k, v in latest_vitals(db, uid).items()},
        "symptoms": [{"id": s["id"], "name": s["name"], "severity": s["severity"], "date": d(s["created_at"])}
                     for s in rows(db, "SELECT * FROM symptoms WHERE user_id=? ORDER BY id DESC", (uid,))],
        "records": [{"id": r["id"], "title": r["title"], "vitals": json.loads(r["vitals_json"]),
                     "symptom": r["notes"] or "None", "date": d(r["created_at"])} for r in recs],
        "medications": [{"id": m["id"], "name": m["name"], "dose": m["dose"] or "", "schedule": m["schedule"] or ""}
                        for m in rows(db, "SELECT * FROM medications WHERE user_id=? ORDER BY id DESC", (uid,))],
        "appointments": [{"id": a["id"], "name": a["name"], "date": a["date"] or "", "time": a["time"] or ""}
                         for a in rows(db, "SELECT * FROM appointments WHERE user_id=? ORDER BY COALESCE(date,'9999'),COALESCE(time,'')", (uid,))],
        "tests": latest_tests(db, uid),
    }


# --- vitals / symptoms / records ---
@app.post("/api/health-entry", status_code=201)
def health_entry(e: HealthEntryIn, u=Depends(current_user), db=Depends(get_db)):
    """Dashboard 'Save My Health Data' form: vitals + optional symptom in one call."""
    symptom = (e.symptom or "").strip()
    if not e.has_any() and not symptom:
        raise HTTPException(422, "Enter some health information first")
    if symptom:
        SymptomIn(name=symptom, severity=e.severity)  # validates severity
        db.execute("INSERT INTO symptoms(user_id,name,severity,created_at) VALUES(?,?,?,?)", (u["id"], symptom, e.severity, now()))
    save_vitals_row(db, u["id"], e, "Health Assessment", symptom or None)
    return {"ok": True}


@app.post("/api/vitals", status_code=201)
def add_vitals(v: VitalsIn, u=Depends(current_user), db=Depends(get_db)):
    if not v.has_any():
        raise HTTPException(422, "Enter at least one measurement")
    save_vitals_row(db, u["id"], v, "Vital Measurement")
    return {"ok": True}


@app.get("/api/vitals")
def vitals_history(limit: int = 50, u=Depends(current_user), db=Depends(get_db)):
    return rows(db, "SELECT id,hr,bp,temp,weight,created_at FROM vitals WHERE user_id=? ORDER BY id DESC LIMIT ?", (u["id"], min(limit, 500)))


@app.post("/api/symptoms", status_code=201)
def add_symptom(s: SymptomIn, u=Depends(current_user), db=Depends(get_db)):
    cur = db.execute("INSERT INTO symptoms(user_id,name,severity,created_at) VALUES(?,?,?,?)", (u["id"], s.name.strip(), s.severity, now()))
    return {"id": cur.lastrowid}


@app.post("/api/records", status_code=201)
def add_record(r: RecordIn, u=Depends(current_user), db=Depends(get_db)):
    cur = db.execute("INSERT INTO records(user_id,title,notes,created_at) VALUES(?,?,?,?)", (u["id"], r.title.strip(), r.notes, now()))
    return {"id": cur.lastrowid}


@app.post("/api/medications", status_code=201)
def add_med(m: MedIn, u=Depends(current_user), db=Depends(get_db)):
    cur = db.execute("INSERT INTO medications(user_id,name,dose,schedule,created_at) VALUES(?,?,?,?,?)", (u["id"], m.name.strip(), m.dose, m.schedule, now()))
    return {"id": cur.lastrowid}


@app.post("/api/appointments", status_code=201)
def add_appt(a: ApptIn, u=Depends(current_user), db=Depends(get_db)):
    cur = db.execute("INSERT INTO appointments(user_id,name,date,time,created_at) VALUES(?,?,?,?,?)", (u["id"], a.name.strip(), a.date, a.time, now()))
    return {"id": cur.lastrowid}


@app.put("/api/medications/{item_id}")
def edit_med(item_id: int, m: MedIn, u=Depends(current_user), db=Depends(get_db)):
    cur = db.execute("UPDATE medications SET name=?,dose=?,schedule=? WHERE id=? AND user_id=?", (m.name.strip(), m.dose, m.schedule, item_id, u["id"]))
    if not cur.rowcount:
        raise HTTPException(404, "Not found")
    return {"ok": True}


@app.put("/api/appointments/{item_id}")
def edit_appt(item_id: int, a: ApptIn, u=Depends(current_user), db=Depends(get_db)):
    cur = db.execute("UPDATE appointments SET name=?,date=?,time=? WHERE id=? AND user_id=?", (a.name.strip(), a.date, a.time, item_id, u["id"]))
    if not cur.rowcount:
        raise HTTPException(404, "Not found")
    return {"ok": True}


DELETABLE = {"symptoms", "records", "medications", "appointments"}


@app.delete("/api/{kind}/{item_id}", status_code=204)
def delete_item(kind: str, item_id: int, u=Depends(current_user), db=Depends(get_db)):
    if kind not in DELETABLE:
        raise HTTPException(404, "Not found")
    cur = db.execute(f"DELETE FROM {kind} WHERE id=? AND user_id=?", (item_id, u["id"]))
    if not cur.rowcount:
        raise HTTPException(404, "Not found")


# --- tests ---
@app.post("/api/tests/{name}", status_code=201)
def submit_test(name: str, t: TestIn, u=Depends(current_user), db=Depends(get_db)):
    if name not in TESTS:
        raise HTTPException(404, "Unknown test")
    spec = TESTS[name]
    if len(t.answers) != len(spec) or any(a not in allowed for a, allowed in zip(t.answers, spec)):
        raise HTTPException(422, "Invalid answers")
    score, mx = sum(t.answers), TEST_MAX[name]
    db.execute("INSERT INTO test_results(user_id,test,score,max,answers_json,created_at) VALUES(?,?,?,?,?,?)",
               (u["id"], name, score, mx, json.dumps(t.answers), now()))
    return {"test": name, "score": score, "max": mx, "percent": round(score / mx * 100)}


@app.get("/api/tests")
def tests(u=Depends(current_user), db=Depends(get_db)):
    return latest_tests(db, u["id"])


# --- insights ---
@app.get("/api/insights")
def insights(u=Depends(current_user), db=Depends(get_db)):
    uid = u["id"]
    vit = {k: ("" if v is None else v) for k, v in latest_vitals(db, uid).items()}
    syms = rows(db, "SELECT name,severity FROM symptoms WHERE user_id=? ORDER BY id DESC LIMIT 20", (uid,))
    n = db.execute("SELECT COUNT(*) FROM records WHERE user_id=?", (uid,)).fetchone()[0]
    return build_insights(profile_of(u), vit, syms, latest_tests(db, uid), n)


# --- frontend ---
STATIC = BASE / "static"
app.mount("/static", StaticFiles(directory=STATIC), name="static")


@app.get("/")
def index():
    return FileResponse(STATIC / "index.html")
