# MediMind backend

FastAPI + SQLite backend for the MediMind frontend. The frontend is served by the same server, so there are no CORS or URL changes.

## Run
```bash
./run.sh                       # or: pip install -r requirements.txt && uvicorn app.main:app --reload
export MEDIMIND_SECRET=...     # set a long random value in production (see .env.example)
```
Open http://localhost:8000 (API docs at /docs). Tests: `pip install pytest httpx && pytest`.

## API (all except /auth/* need `Authorization: Bearer <token>`)
| Method | Path | Purpose |
|---|---|---|
| POST | /api/auth/register, /api/auth/login | Create account / sign in -> `{token}` |
| GET / PUT | /api/profile | Name, age, height (cm), weight (kg) |
| GET | /api/state | Everything the UI renders (profile, latest vitals, records, symptoms, meds, appointments, tests) |
| POST | /api/health-entry | Dashboard form: vitals + optional symptom |
| POST / GET | /api/vitals | Record vitals / history |
| POST | /api/symptoms, /api/records, /api/medications, /api/appointments | Add items |
| PUT | /api/medications/{id}, /api/appointments/{id} | Edit |
| DELETE | /api/{symptoms,records,medications,appointments}/{id} | Delete |
| POST | /api/tests/{heart,sleep,life} | Body `{"answers":[...]}`, scored server-side |
| GET | /api/insights | Tips, tags, assessment, BMI |
| DELETE | /api/account | Delete the account and all its data |

## Notes
- Passwords: scrypt-hashed. Auth: JWT (HS256), expiry via MEDIMIND_TOKEN_HOURS.
- Every query is scoped to the logged-in user.
- Temperature is in °F, as in the UI.
- Health data is sensitive: serve over HTTPS, set MEDIMIND_SECRET and MEDIMIND_CORS, and back up the DB file.
- Frontend fixes: added the missing `id="app"` and `calcBox` elements, fixed the blood-pressure regex, and wired the BMI card on Health Tests.
